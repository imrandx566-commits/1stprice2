# Supabase setup (Probashi Voice)

1. Open the Supabase project's SQL Editor.
2. Paste and run `schema.sql` from this folder.
3. In Supabase Dashboard → Authentication → Users, create/invite `dxismailhossen4@gmail.com` and complete the email flow.
4. Copy that user's UUID from Authentication → Users.
5. Run this one-time SQL, replacing `PASTE_AUTH_USER_UUID` with that exact UUID:

```sql
update public.profiles
set role = 'super_admin'
where id = 'PASTE_AUTH_USER_UUID'::uuid
  and lower(email) = 'dxismailhossen4@gmail.com';
```

6. Verify it changed exactly one row and check:

```sql
select id, email, role
from public.profiles
where lower(email) = 'dxismailhossen4@gmail.com';
```

Important: do not run the role update until the email/user UUID has been verified. Never put a Supabase `service_role` key in frontend files. Use only the project URL and publishable/anon key in browser configuration. This schema does not create an Auth user by itself.
