-- Probashi Voice initial schema
-- Run in Supabase SQL Editor. Then create/sign up the Super Admin user in Supabase Auth
-- and run the one-time bootstrap statement documented in SETUP-SUPABASE.md.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text unique,
  role text not null default 'user' check (role in ('user','admin','super_admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.number_records (
  id uuid primary key default gen_random_uuid(),
  country text not null,
  draw_date date,
  number_value text not null check (number_value ~ '^[0-9]{3,4}$'),
  source_label text,
  notes text,
  is_published boolean not null default false,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists number_records_search_idx
  on public.number_records (country, number_value, draw_date desc);
create index if not exists number_records_published_idx
  on public.number_records (is_published, draw_date desc);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  insert into public.profiles (id, email, role)
  values (new.id, new.email, 'user')
  on conflict (id) do update set email = excluded.email;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.set_updated_at()
returns trigger language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;
drop trigger if exists number_records_set_updated_at on public.number_records;
create trigger number_records_set_updated_at
before update on public.number_records
for each row execute function public.set_updated_at();

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = ''
as $$
  select exists (
    select 1 from public.profiles p
    where p.id = (select auth.uid())
      and p.role in ('admin','super_admin')
  );
$$;

alter table public.profiles enable row level security;
alter table public.number_records enable row level security;

drop policy if exists "Users can read own profile" on public.profiles;
create policy "Users can read own profile"
on public.profiles for select to authenticated
using (id = (select auth.uid()) or public.is_admin());

drop policy if exists "Published numbers are public" on public.number_records;
create policy "Published numbers are public"
on public.number_records for select to anon, authenticated
using (is_published = true or public.is_admin());

drop policy if exists "Admins can insert number records" on public.number_records;
create policy "Admins can insert number records"
on public.number_records for insert to authenticated
with check (public.is_admin() and (created_by is null or created_by = (select auth.uid())));

drop policy if exists "Admins can update number records" on public.number_records;
create policy "Admins can update number records"
on public.number_records for update to authenticated
using (public.is_admin())
with check (public.is_admin());

drop policy if exists "Admins can delete number records" on public.number_records;
create policy "Admins can delete number records"
on public.number_records for delete to authenticated
using (public.is_admin());

-- No client-side policy permits changing profiles/roles.
