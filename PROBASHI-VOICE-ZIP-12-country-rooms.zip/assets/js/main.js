// Dynamic Countdown Timers
function startTimer(durationInSeconds, displayElementId) {
  let timer = durationInSeconds;
  const display = document.getElementById(displayElementId);
  if (!display) return;

  const render = () => {
    const days = Math.floor(timer / 86400);
    const hours = Math.floor((timer % 86400) / 3600);
    const minutes = Math.floor((timer % 3600) / 60);
    const seconds = timer % 60;
    display.textContent = `${String(days).padStart(2, '0')}d ${String(hours).padStart(2, '0')}h ${String(minutes).padStart(2, '0')}m ${String(seconds).padStart(2, '0')}s`;
  };

  render();
  setInterval(() => {
    timer -= 1;
    if (timer < 0) timer = durationInSeconds;
    render();
  }, 1000);
}

// Historical Number Search: queries only published Supabase records when configured.
async function searchNumber() {
  const input = document.getElementById('numberSearch')?.value.trim();
  const resultMsg = document.getElementById('searchResult');
  if (!resultMsg) return;
  if (!/^\\d{3,4}$/.test(input || '')) {
    resultMsg.textContent = 'Please enter a valid 3-digit or 4-digit number.';
    resultMsg.style.color = '#ff4d4d';
    return;
  }
  const url = window.PROBASHI_SUPABASE_URL;
  const key = window.PROBASHI_SUPABASE_ANON_KEY;
  if (!window.supabase || !url || url.includes('YOUR_PROJECT_REF') || !key || key.includes('YOUR_')) {
    resultMsg.style.color = '#d4af37';
    resultMsg.textContent = 'Search is not connected yet. Configure Supabase URL and publishable/anon key, then run the database schema.';
    return;
  }
  resultMsg.textContent = 'Searching published archive…';
  resultMsg.style.color = '#d4af37';
  const client = window.supabase.createClient(url, key);
  const { data, error } = await client.from('number_records')
    .select('country,number_value,draw_date,source_label,notes')
    .eq('number_value', input).eq('is_published', true)
    .order('draw_date', {ascending:false}).limit(50);
  if (error) {
    resultMsg.textContent = 'Search failed: ' + error.message;
    resultMsg.style.color = '#ff4d4d';
    return;
  }
  if (!data || !data.length) {
    resultMsg.textContent = `No published archive records found for ${input}.`;
    return;
  }
  const list = document.createElement('ul');
  data.forEach(row => {
    const li = document.createElement('li');
    li.textContent = `${row.country} · ${row.number_value} · ${row.draw_date || 'Date not set'}${row.source_label ? ' · '+row.source_label : ''}${row.notes ? ' — '+row.notes : ''}`;
    list.appendChild(li);
  });
  resultMsg.replaceChildren(document.createTextNode(`Found ${data.length} published record(s):`), list);
}

// Policy Modal Controls
function openModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) modal.style.display = 'block';
}

function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) modal.style.display = 'none';
}

window.addEventListener('click', function (event) {
  if (event.target.classList.contains('modal')) event.target.style.display = 'none';
});

// Initialize Timers on Page Load
// Demo durations retained until official draw schedules are connected.
document.addEventListener('DOMContentLoaded', function () {
  startTimer(172800, 'thaiTimer');
  startTimer(43200, 'malaysiaTimer');
});
