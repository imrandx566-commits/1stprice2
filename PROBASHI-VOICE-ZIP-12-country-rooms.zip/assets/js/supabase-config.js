// Set these values from Supabase Dashboard → Project Settings → API.
// Use the publishable/anon key only. NEVER place a service_role/secret key here.
window.PROBASHI_SUPABASE_URL = 'https://YOUR_PROJECT_REF.supabase.co';
window.PROBASHI_SUPABASE_ANON_KEY = 'YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY';
