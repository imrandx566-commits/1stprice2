PROBASHI VOICE — Visual Update Notes

- Kept the existing project structure, country pages, links, and features.
- Refined the global palette to midnight navy and warm gold, inspired by the supplied reference image.
- Homepage country cards now display their own existing country-specific room photo (including a person and location/landmark), with a dark readable overlay and gold entry button.
- The eight country room pages already use their own room images in the page hero; those paths remain unchanged.
- This is a front-end visual update only. It does not connect a live results feed or validate any prediction/result data.
