# PROBASHI VOICE — ZIP-12 package verification

## Design/package checks
- Midnight navy + gold theme follows the supplied reference image.
- Homepage cards show country-specific room backgrounds featuring a person and local environment.
- Each of the eight country cards links to its own local country HTML page.
- Malaysia and Singapore pages and their image assets are included.
- CSS, JavaScript, image assets, homepage, admin page, and Supabase setup notes are included.

## Not yet live/verified
- This ZIP has not been deployed to a public hosting URL.
- Supabase credentials, database tables, and admin role must be configured and tested by the site owner.
- Countdown timings are not certified against official draw schedules.
- Telegram channel and VIP prices/benefits require owner-approved details.

Do not place a Supabase service_role key in browser code. Sample/prediction values must not be represented as verified official results.
